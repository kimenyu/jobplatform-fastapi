from sqlalchemy.orm import declarative_base

# All models will inherit from this base
Base = declarative_base()
